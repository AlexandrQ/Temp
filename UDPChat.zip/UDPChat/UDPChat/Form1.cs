﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;
using System.Threading;
using System.Diagnostics;

namespace UDPChat
{
    public partial class Form1 : Form
    {   
        const int LOCALPORT = 8001;         // порт для приема сообщений
        const int REMOTEPORT = 8001;        // порт для отправки сообщений
        const int FILELOCALPORT = 8002;     // порт для приема file
        const int FILEREMOTEPORT = 8002;    // порт для отправки file
        const int TTL = 20;
        const string HOST = "235.5.5.1";    // хост для групповой рассылки
        IPAddress groupAddress;             // адрес для групповой рассылки
        UdpClient messageClient;
        UdpClient udpFileClient;
        bool alive = false;                 // будет ли работать поток для приема
        string userName;                    // имя пользователя в чате
        //IPEndPoint endPoint;
        FileStream fs;
        Byte[] receiveBytes = new Byte[0];
        private static IPEndPoint RemoteIpEndPoint = null;



        private static FileDetails fileDet = new FileDetails();

        public Form1()
        {
            InitializeComponent();

            loginButton.Enabled = true;     // кнопка входа
            sendButton.Enabled = false;     // кнопка отправки
            chatTextBox.ReadOnly = true;    // поле для сообщений
            logoutButton.Enabled = false;   // кнопка выхода
            sendFileButton.Enabled = false; //
            selectFileButton.Enabled = false; //            

            groupAddress = IPAddress.Parse(HOST);
            
        }

        

        //нажатие кнопки loginButton
        private void loginButton_Click(object sender, EventArgs e)
        {
            userName = nickNameTextBox.Text;
            nickNameTextBox.ReadOnly = true;

            try
            {
                messageClient = new UdpClient(LOCALPORT);

                //присоединяемся к групповой рассылке
                messageClient.JoinMulticastGroup(groupAddress, TTL);

                //запускаем задачу на прием сообщений
                Task recieveTask = new Task(ReceiveMessages);
                recieveTask.Start();

                Task recieveFileTask = new Task(GetFileDetails);
                recieveFileTask.Start();
                

                //отправляем первое сообщение о входе нового пользователя
                string message = userName + " вошел в чат";
                byte[] data = Encoding.Unicode.GetBytes(message);
                messageClient.Send(data, data.Length, HOST, REMOTEPORT);

                loginButton.Enabled = false;
                logoutButton.Enabled = true;
                sendButton.Enabled = true;
                sendFileButton.Enabled = true;
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //
        private void SendFileInfo()
        {

            // Получаем тип и расширение файла
            fileDet.FILETYPE = fs.Name.Substring((int)fs.Name.Length - 3, 3);

            // Получаем длину файла
            fileDet.FILESIZE = fs.Length;

            XmlSerializer fileSerializer = new XmlSerializer(typeof(FileDetails));
            MemoryStream stream = new MemoryStream();

            // Сериализуем объект
            fileSerializer.Serialize(stream, fileDet);

            // Считываем поток в байты
            stream.Position = 0;
            Byte[] bytes = new Byte[stream.Length];
            stream.Read(bytes, 0, Convert.ToInt32(stream.Length));

            // Отправляем информацию о файле
            udpFileClient = new UdpClient(FILELOCALPORT);
            udpFileClient.JoinMulticastGroup(groupAddress, TTL);
            udpFileClient.Send(bytes, bytes.Length, HOST, FILEREMOTEPORT);
            stream.Close();

        }


        void GetFileDetails()
        {
            alive = true;
            try
            {
                while (alive)
                {
                    // Получаем информацию о файле
                    receiveBytes = udpFileClient.Receive(ref RemoteIpEndPoint);

                    XmlSerializer fileSerializer = new XmlSerializer(typeof(FileDetails));
                    MemoryStream stream1 = new MemoryStream();

                    // Считываем информацию о файле
                    stream1.Write(receiveBytes, 0, receiveBytes.Length);
                    stream1.Position = 0;

                    // Вызываем метод Deserialize
                    fileDet = (FileDetails)fileSerializer.Deserialize(stream1);

                    this.Invoke(new MethodInvoker(() =>
                    {
                        string time = DateTime.Now.ToShortTimeString();
                        chatTextBox.Text = time + "Получен файл типа ." + fileDet.FILETYPE + " имеющий размер " + fileDet.FILESIZE.ToString() + " байт" + "\r\n" + chatTextBox.Text;
                    }));
                    ReceiveFile();
                }
                
            }
            catch (ObjectDisposedException)
            {
                if (!alive)
                    return;
                throw;
            }
            catch (Exception eR)
            {
                MessageBox.Show(eR.ToString());
            }
        }



        void ReceiveFile()
        {
            alive = true;
            try
            {  
                // Получаем файл
                IPEndPoint RemoteIpEndPoint = null;
                receiveBytes = udpFileClient.Receive(ref RemoteIpEndPoint);

                // Создаем временный файл с полученным расширением
                fs = new FileStream("temp." + fileDet.FILETYPE, FileMode.Create, FileAccess.ReadWrite, FileShare.ReadWrite);
                fs.Write(receiveBytes, 0, receiveBytes.Length);

                // Открываем файл связанной с ним программой
                Process.Start(fs.Name);
                
            }
            catch (ObjectDisposedException)
            {
                if (!alive)
                    return;
                throw;
            }
            catch (Exception eR)
            {
                Console.WriteLine(eR.ToString());
            }
            finally
            {
                fs.Close();                
            }
        }


        //
        private void SendFile()
        {
            // Создаем файловый поток и переводим его в байты
            Byte[] bytes = new Byte[fs.Length];
            fs.Read(bytes, 0, bytes.Length);
                        
            try
            {
                // Отправляем файл
                udpFileClient.Send(bytes, bytes.Length, HOST, FILEREMOTEPORT);
            }            
            catch (Exception eR)
            {
                Console.WriteLine(eR.ToString());
            }
            finally
            {
                // Закрываем соединение и очищаем поток
                fs.Close();
                
            }            
        }

        //метод приема сообщений
        private void ReceiveMessages()
        {
            alive = true;
            try
            {
                while (alive)
                {
                    IPEndPoint remoteIP = null;
                    byte[] data = messageClient.Receive(ref remoteIP);
                    string message = Encoding.Unicode.GetString(data);

                    //добавляем полученное сообщение в текстовое поле
                    this.Invoke(new MethodInvoker(() =>
                    {
                        string time = DateTime.Now.ToShortTimeString();
                        chatTextBox.Text = time + " " + message + "\r\n" + chatTextBox.Text;
                    }));
                }
            }
            catch (ObjectDisposedException)
            {
                if (!alive)
                    return;
                throw;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void sendButton_Click(object sender, EventArgs e)
        {
            try
            {
                string message = String.Format("{0}: {1}", userName, messageTextBox.Text);
                byte[] data = Encoding.Unicode.GetBytes(message);
                messageClient.Send(data, data.Length, HOST, REMOTEPORT);
                messageTextBox.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void logoutButton_Click(object sender, EventArgs e)
        {
            ExitChat();
        }


        private void ExitChat()
        {
            string message = userName + " покидает чат";
            byte[] data = Encoding.Unicode.GetBytes(message);
            messageClient.Send(data, data.Length, HOST, REMOTEPORT);
            messageClient.DropMulticastGroup(groupAddress);

            alive = false;
            messageClient.Close();
            udpFileClient.Close();

            loginButton.Enabled = true;
            logoutButton.Enabled = false;
            sendButton.Enabled = false;
            sendFileButton.Enabled = false;
            selectFileButton.Enabled = false;
        }

        // обработчик события закрытия формы
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (alive)
                ExitChat();
        }

        private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {
            SelectFileLabel.Text = openFileDialog1.FileName; //Split('\\')[openFileDialog1.FileName.Split('\\').Length-1];
            fs = new FileStream(openFileDialog1.FileName, FileMode.Open, FileAccess.Read);

            sendFileButton.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void sendFileButton_Click(object sender, EventArgs e)
        {
            // Отправляем информацию о файле
            SendFileInfo();

            // Ждем 2 секунды
            Thread.Sleep(2000);


            // Отправляем сам файл
            SendFile();
        }
    }
}
